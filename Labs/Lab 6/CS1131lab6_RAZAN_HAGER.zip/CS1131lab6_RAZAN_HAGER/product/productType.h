#include <string>
#include <iostream>
using namespace std;

class productType
{
public: //methods
 productType(); //constructor
 productType(int, double, double); //overloaded constructor
 productType(string, int, double, double); //overloaded constuctor
 productType(string, string, string, int, double, double); //overloaded constructor
 void set(string, string, string, int, double, double); //setter
 void print() const; //print function
 void setQuantitiesInStock(int x); //quantity setter
 void updateQuantitiesInStock(int x); //updating function
 int getQuantitiesInStock() const; //quantity getter
 void setPrice(double x); //price setter
 double getPrice() const; //price getter
 void setDiscount(double d); //discount setter
 double getDiscount() const; //discount getter

private: //attirbutes
 string productName;
 string id;
 string manufacturer;
 int quantitiesInStock;
 double price;
 double discount;
};
