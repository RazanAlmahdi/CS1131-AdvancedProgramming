#include <iostream>
#include "productType.h"
#include <string>
using namespace std;



int main(){

    productType pt;

    // checking the degault values
    pt.print();

// declaring variables
    string pName, pID, manufact;


// taking the data from the user
    cout << "Enter the Product name: ";
    cin >> pName;
    cout << endl;

    cout << "Enter the Product ID: ";
    cin >> pID;
    cout << endl;

    cout << "Enter the Manufacturer: ";
    cin >> manufact;
    cout << endl;


// insertig the object into the class
// using the information we get from the user
// the last 3 values are: quantity in stock, pric, dis. (which cannot be taken from the user)
    pt.set(pName, pID, manufact, 3, 70, 20);
// printing out the results
    pt.print();


// declaring variables that are needed
    double pric, dis;
    int quantity;


// Quantity in stock
    cout << "Enter quantity in stock: ";
    cin >> quantity;
    pt.setQuantitiesInStock(quantity);

    cout << "Quantity in stock is " << pt.getQuantitiesInStock();
    pt.updateQuantitiesInStock(50);
    cout << " and the updated quantity in stock is " << pt.getQuantitiesInStock() << endl;


// The price
    cout << "Enter price: ";
    cin >> pric;
    cout << endl;

    pt.setPrice(pric);
    cout << "The price is:" << pt.getPrice() << "$" << endl;


// discount
    cout << "Enter discount: ";
    cin >> dis;
    cout << endl;

    pt.setDiscount(dis);
    cout << "The discount is:" << pt.getDiscount() << "%" << endl;


return 0;

}
