#include <iostream>
#include "productType.h"
using namespace std;

//setter function
void productType::set(string pName,string pID,string manufact,int quantity, double pric,double dis){

  productName=pName;
  id=pID;
  manufacturer=manufact;
  quantitiesInStock=quantity;
  price=pric;
  discount=dis;

}

//print
void productType::print() const{

cout<<"Product Name :"<<productName<<endl;
cout<<"pID:"<<id<<endl;
cout<<"manufac :"<<manufacturer<<endl;
cout<<"Quantities In Stock :"<<quantitiesInStock<<endl;
cout<<"Price :$"<<price<<endl;
cout<<"Discount :%"<<discount<<endl;

}

//setter quantity
void productType::setQuantitiesInStock(int x){

quantitiesInStock=x;

}

//getter quantity
int productType::getQuantitiesInStock() const{

return quantitiesInStock;

}

//setter price
void productType::setPrice(double x){

price=x;

}

//getter price
double productType::getPrice() const{

return price;

}

//setter discount
void productType::setDiscount(double dic){

discount=dic;

}

//getter discount
double productType::getDiscount() const{

return discount;

}

//update quantity
void productType::updateQuantitiesInStock(int x){

quantitiesInStock=x;

}

//constructor
productType::productType(){

  productName="";
  id="";
  manufacturer="";
  quantitiesInStock=0;
  price=0.0;
  discount=0.0;

}

//overloaded constructor
productType::productType(int quantity, double pric,double dis){

  productName="";
  id="";
  manufacturer="";
  quantitiesInStock=quantity;
  price=pric;
  discount=dis;

}

//overloaded constructor
productType::productType(string pName,int quantity, double pric,double dis){
  productName=pName;
  id="";
  manufacturer="";
  quantitiesInStock=quantity;
  price=pric;
  discount=dis;

}

//overloaded constructor
productType::productType(string pName,string pID,string manufact,int quantity, double pric,double dis){

  productName=pName;
  id=pID;
  manufacturer=manufact;
  quantitiesInStock=quantity;
  price=pric;
  discount=dis;

}
