#include <iostream>
#include "counterType.h"
using namespace std;

int main()
{
	counterType counterObj; //creating object
	int c;

	cout<<"Enter the value of counter: "<<endl; //prompt user for input
	cin>>c;

	counterObj.setCounter(c); // call setter
	cout<<"Value of counter initially : "<<counterObj.getCounter()<<endl; //call getter
	cout<<"Value of counter after Incrementing : "<<counterObj.incrementCounter()<<endl; //call increment
	cout<<"Value of counter after Decrementing : "<<counterObj.decrementCounter()<<endl; //call decrement
	cout<<endl;

	counterObj.print(); // print

}
