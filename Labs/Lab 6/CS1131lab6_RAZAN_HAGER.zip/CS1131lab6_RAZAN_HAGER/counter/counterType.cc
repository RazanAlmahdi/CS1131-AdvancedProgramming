#include <iostream>
#include "counterType.h"


	counterType:: counterType() //constructor
	{
		counter = 0;
	}

	void counterType:: setCounter(int c) //setter
	{
		counter = c;
	}

	int counterType::getCounter() //getter
	{
		return counter;
	}

	int counterType:: incrementCounter() //increment function
	{
		return ++counter;
	}

	int counterType:: decrementCounter() //decrement function
	{
		if(counter < 0)
		{
			cout<<endl;
			cout<<"The value of the counter is negative "<< endl;
			return 0;
		}
		else
		return --counter;
	}

	void  counterType:: print() //print function
	{
		cout<<"The final value of Counter : "<<counter << endl;
	}
