#include <iostream>
#include <string>

using namespace std;

class counterType
{
    private: //attribute
    int counter;

    public: //methods or functions
    counterType();
    void setCounter(int c);
    int getCounter();
    int incrementCounter();
    int decrementCounter();
    void print();
};
